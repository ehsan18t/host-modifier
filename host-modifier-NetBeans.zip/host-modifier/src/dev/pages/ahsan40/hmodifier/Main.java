/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dev.pages.ahsan40.hmodifier;

/**
 *
 * @author Ahsan
 */
public class Main {
    public static void main(String[] args) {
        // start gui
        java.awt.EventQueue.invokeLater(() -> new MainFrame().setVisible(true));
        // System.out.println(Thread.currentThread().getId()); // debug
    }
}
